<!doctype html>
<html dir="ltr" lang="en-US" prefix="og: https://ogp.me/ns#">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
	<meta name='impact-site-verification' value='46899ee6-afb9-431d-8436-6de1ce3c9b7a' />
    <title>Page Not Found</title>

		<!-- All in One SEO 4.9.3 - aioseo.com -->
	<meta name="robots" content="noindex" />
	<meta name="p:domain_verify" content="553ea8d2f451e358dc167d883d340218" />
	<meta name="generator" content="All in One SEO (AIOSEO) 4.9.3" />
		<script type="application/ld+json" class="aioseo-schema">
			{"@context":"https:\/\/schema.org","@graph":[{"@type":"BreadcrumbList","@id":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/#breadcrumblist","itemListElement":[{"@type":"ListItem","@id":"https:\/\/www.adminuiux.com#listItem","position":1,"name":"Home","item":"https:\/\/www.adminuiux.com","nextItem":{"@type":"ListItem","@id":"#listItem","name":"404 - Page Not Found"}}]},{"@type":"Organization","@id":"https:\/\/www.adminuiux.com\/#organization","name":"Admin UI UX","description":"Web and mobile Bootstrap themes HTML templates","url":"https:\/\/www.adminuiux.com\/","logo":{"@type":"ImageObject","url":"https:\/\/www.adminuiux.com\/wp-content\/uploads\/2022\/08\/adminuiux-templates.svg","@id":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/#organizationLogo","width":186,"height":32,"caption":"admin ui ux best web and mobile HTML templates"},"image":{"@id":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/#organizationLogo"},"sameAs":["https:\/\/www.facebook.com\/adminuiux","https:\/\/x.com\/admiinuiux","https:\/\/www.instagram.com\/adminuiux","https:\/\/in.pinterest.com\/AdminUIUX\/","https:\/\/www.linkedin.com\/company\/adminuiux\/"]},{"@type":"WebPage","@id":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/#webpage","url":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/","inLanguage":"en-US","isPartOf":{"@id":"https:\/\/www.adminuiux.com\/#website"},"breadcrumb":{"@id":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/#breadcrumblist"}},{"@type":"WebSite","@id":"https:\/\/www.adminuiux.com\/#website","url":"https:\/\/www.adminuiux.com\/","name":"Admin UI UX","description":"Web and mobile Bootstrap themes HTML templates","inLanguage":"en-US","publisher":{"@id":"https:\/\/www.adminuiux.com\/#organization"}}]}
		</script>
		<script type="text/javascript">
			(function(c,l,a,r,i,t,y){
			c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;
			t.src="https://www.clarity.ms/tag/"+i+"?ref=aioseo";y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
		})(window, document, "clarity", "script", "v9vd37g8vl");
		</script>
		<!-- All in One SEO -->

<link rel='dns-prefetch' href='//static.addtoany.com' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel="alternate" type="application/rss+xml" title="Admin UI UX &raquo; Feed" href="https://www.adminuiux.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Admin UI UX &raquo; Comments Feed" href="https://www.adminuiux.com/comments/feed/" />
		<!-- This site uses the Google Analytics by MonsterInsights plugin v11.2.0 - Using Analytics tracking - https://www.monsterinsights.com/ -->
							<script src="//www.googletagmanager.com/gtag/js?id=G-Z9LSH6MRZR"  data-cfasync="false" data-wpfc-render="false" async></script>
			<script data-cfasync="false" data-wpfc-render="false">
				var mi_version = '11.2.0';
				var mi_track_user = true;
				var mi_no_track_reason = '';
								var MonsterInsightsDefaultLocations = {"page_location":"https:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/src\/icon.js\/","page_referrer":"http:\/\/www.adminuiux.com\/adminuiux\/investment-uiux\/assets\/js\/app.js?1096aad991449c8654b2"};
								if ( typeof MonsterInsightsPrivacyGuardFilter === 'function' ) {
					var MonsterInsightsLocations = (typeof MonsterInsightsExcludeQuery === 'object') ? MonsterInsightsPrivacyGuardFilter( MonsterInsightsExcludeQuery ) : MonsterInsightsPrivacyGuardFilter( MonsterInsightsDefaultLocations );
				} else {
					var MonsterInsightsLocations = (typeof MonsterInsightsExcludeQuery === 'object') ? MonsterInsightsExcludeQuery : MonsterInsightsDefaultLocations;
				}

								var disableStrs = [
										'ga-disable-G-Z9LSH6MRZR',
									];

				/* Function to detect opted out users */
				function __gtagTrackerIsOptedOut() {
					for (var index = 0; index < disableStrs.length; index++) {
						if (document.cookie.indexOf(disableStrs[index] + '=true') > -1) {
							return true;
						}
					}

					return false;
				}

				/* Disable tracking if the opt-out cookie exists. */
				if (__gtagTrackerIsOptedOut()) {
					for (var index = 0; index < disableStrs.length; index++) {
						window[disableStrs[index]] = true;
					}
				}

				/* Opt-out function */
				function __gtagTrackerOptout() {
					for (var index = 0; index < disableStrs.length; index++) {
						document.cookie = disableStrs[index] + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
						window[disableStrs[index]] = true;
					}
				}

				if ('undefined' === typeof gaOptout) {
					function gaOptout() {
						__gtagTrackerOptout();
					}
				}
								window.dataLayer = window.dataLayer || [];

				window.MonsterInsightsDualTracker = {
					helpers: {},
					trackers: {},
				};
				if (mi_track_user) {
					function __gtagDataLayer() {
						dataLayer.push(arguments);
					}

					function __gtagTracker(type, name, parameters) {
						if (!parameters) {
							parameters = {};
						}

						if (parameters.send_to) {
							__gtagDataLayer.apply(null, arguments);
							return;
						}

						if (type === 'event') {
														parameters.send_to = monsterinsights_frontend.v4_id;
							var hookName = name;
							if (typeof parameters['event_category'] !== 'undefined') {
								hookName = parameters['event_category'] + ':' + name;
							}

							if (typeof MonsterInsightsDualTracker.trackers[hookName] !== 'undefined') {
								MonsterInsightsDualTracker.trackers[hookName](parameters);
							} else {
								__gtagDataLayer('event', name, parameters);
							}
							
						} else {
							__gtagDataLayer.apply(null, arguments);
						}
					}

					__gtagTracker('js', new Date());
					__gtagTracker('set', {
						'developer_id.dZGIzZG': true,
											});
					if ( MonsterInsightsLocations.page_location ) {
						__gtagTracker('set', MonsterInsightsLocations);
					}
										__gtagTracker('config', 'G-Z9LSH6MRZR', {"forceSSL":"true","link_attribution":"true","page_path":'\/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer} );
										window.gtag = __gtagTracker;										(function () {
						/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
						/* ga and __gaTracker compatibility shim. */
						var noopfn = function () {
							return null;
						};
						var newtracker = function () {
							return new Tracker();
						};
						var Tracker = function () {
							return null;
						};
						var p = Tracker.prototype;
						p.get = noopfn;
						p.set = noopfn;
						p.send = function () {
							var args = Array.prototype.slice.call(arguments);
							args.unshift('send');
							__gaTracker.apply(null, args);
						};
						var __gaTracker = function () {
							var len = arguments.length;
							if (len === 0) {
								return;
							}
							var f = arguments[len - 1];
							if (typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function') {
								if ('send' === arguments[0]) {
									var hitConverted, hitObject = false, action;
									if ('event' === arguments[1]) {
										if ('undefined' !== typeof arguments[3]) {
											hitObject = {
												'eventAction': arguments[3],
												'eventCategory': arguments[2],
												'eventLabel': arguments[4],
												'value': arguments[5] ? arguments[5] : 1,
											}
										}
									}
									if ('pageview' === arguments[1]) {
										if ('undefined' !== typeof arguments[2]) {
											hitObject = {
												'eventAction': 'page_view',
												'page_path': arguments[2],
											}
										}
									}
									if (typeof arguments[2] === 'object') {
										hitObject = arguments[2];
									}
									if (typeof arguments[5] === 'object') {
										Object.assign(hitObject, arguments[5]);
									}
									if ('undefined' !== typeof arguments[1].hitType) {
										hitObject = arguments[1];
										if ('pageview' === hitObject.hitType) {
											hitObject.eventAction = 'page_view';
										}
									}
									if (hitObject) {
										action = 'timing' === arguments[1].hitType ? 'timing_complete' : hitObject.eventAction;
										hitConverted = mapArgs(hitObject);
										__gtagTracker('event', action, hitConverted);
									}
								}
								return;
							}

							function mapArgs(args) {
								var arg, hit = {};
								var gaMap = {
									'eventCategory': 'event_category',
									'eventAction': 'event_action',
									'eventLabel': 'event_label',
									'eventValue': 'event_value',
									'nonInteraction': 'non_interaction',
									'timingCategory': 'event_category',
									'timingVar': 'name',
									'timingValue': 'value',
									'timingLabel': 'event_label',
									'page': 'page_path',
									'location': 'page_location',
									'title': 'page_title',
									'referrer' : 'page_referrer',
								};
								for (arg in args) {
																		if (!(!args.hasOwnProperty(arg) || !gaMap.hasOwnProperty(arg))) {
										hit[gaMap[arg]] = args[arg];
									} else {
										hit[arg] = args[arg];
									}
								}
								return hit;
							}

							try {
								f.hitCallback();
							} catch (ex) {
							}
						};
						__gaTracker.create = newtracker;
						__gaTracker.getByName = newtracker;
						__gaTracker.getAll = function () {
							return [];
						};
						__gaTracker.remove = noopfn;
						__gaTracker.loaded = true;
						window['__gaTracker'] = __gaTracker;
					})();
									} else {
										console.log("");
					(function () {
						function __gtagTracker() {
							return null;
						}

						window['__gtagTracker'] = __gtagTracker;
						window['gtag'] = __gtagTracker;
					})();
									}
			</script>
							<!-- / Google Analytics by MonsterInsights -->
		<style id="wp-img-auto-sizes-contain-inline-css">
img:is([sizes=auto i],[sizes^="auto," i]){contain-intrinsic-size:3000px 1500px}
/*# sourceURL=wp-img-auto-sizes-contain-inline-css */
</style>
<style id="wp-emoji-styles-inline-css">

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
/*# sourceURL=wp-emoji-styles-inline-css */
</style>
<style id="classic-theme-styles-inline-css">
/*! This file is auto-generated */
.wp-block-button__link{color:#fff;background-color:#32373c;border-radius:9999px;box-shadow:none;text-decoration:none;padding:calc(.667em + 2px) calc(1.333em + 2px);font-size:1.125em}.wp-block-file__button{background:#32373c;color:#fff;text-decoration:none}
/*# sourceURL=/wp-includes/css/classic-themes.min.css */
</style>

<link rel='stylesheet' id='wc-blocks-style-css' href='https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/client/blocks/wc-blocks.css?ver=wc-9.8.7' media='all' />

<style id="global-styles-inline-css">
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgb(6,147,227) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgb(252,185,0) 0%,rgb(255,105,0) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgb(255,105,0) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgb(255, 255, 255), 6px 6px rgb(0, 0, 0);--wp--preset--shadow--crisp: 6px 6px 0px rgb(0, 0, 0);}.wp-block-button{--wp--preset--dimension--25: 25%;--wp--preset--dimension--50: 50%;--wp--preset--dimension--75: 75%;--wp--preset--dimension--100: 100%;}:where(body) { margin: 0; }:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}body{padding-top: 0px;padding-right: 0px;padding-bottom: 0px;padding-left: 0px;}:root :where(.wp-element-button, .wp-block-button__link){background-color: #32373c;border-width: 0;color: #fff;font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit;letter-spacing: inherit;line-height: inherit;padding-top: calc(0.667em + 2px);padding-right: calc(1.333em + 2px);padding-bottom: calc(0.667em + 2px);padding-left: calc(1.333em + 2px);text-decoration: none;text-transform: inherit;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
/*# sourceURL=global-styles-inline-css */
</style>

<link rel='stylesheet' id='woocommerce-layout-css' href='https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=9.8.7' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css' href='https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=9.8.7' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css' href='https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=9.8.7' media='all' />
<style id="woocommerce-inline-inline-css">
.woocommerce form .form-row .required { visibility: visible; }
/*# sourceURL=woocommerce-inline-inline-css */
</style>
<link rel='stylesheet' id='woo-variation-swatches-css' href='https://www.adminuiux.com/wp-content/plugins/woo-variation-swatches/assets/css/frontend.min.css?ver=1766032116' media='all' />
<style id="woo-variation-swatches-inline-css">
:root {
--wvs-tick:url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 2px rgb(0 0 0 / .8))' xmlns='http://www.w3.org/2000/svg'  viewBox='0 0 30 30'%3E%3Cpath fill='none' stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='4' d='M4 16L11 23 27 7'/%3E%3C/svg%3E");

--wvs-cross:url("data:image/svg+xml;utf8,%3Csvg filter='drop-shadow(0px 0px 5px rgb(255 255 255 / .6))' xmlns='http://www.w3.org/2000/svg' width='72px' height='72px' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='%23ff0000' stroke-linecap='round' stroke-width='0.6' d='M5 5L19 19M19 5L5 19'/%3E%3C/svg%3E");
--wvs-single-product-item-width:30px;
--wvs-single-product-item-height:30px;
--wvs-single-product-item-font-size:16px}
/*# sourceURL=woo-variation-swatches-inline-css */
</style>
<link rel='stylesheet' id='brands-styles-css' href='https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/css/brands.css?ver=9.8.7' media='all' />
<link rel='stylesheet' id='bootstrap-css' href='https://www.adminuiux.com/wp-content/themes/apptek/assets/css/bootstrap.min.css?ver=1788624552' media='all' />
<link rel='stylesheet' id='apptek-fonts-css' href='https://fonts.googleapis.com/css?family=Plus+Jakarta+Sans%3A500%7CPlus+Jakarta+Sans%3A700%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A500%7CPlus+Jakarta+Sans%3A700%7CPlus+Jakarta+Sans%3A600%7CPlus+Jakarta+Sans%3A700%7CPlus+Jakarta+Sans%3A700%7CPlus+Jakarta+Sans%3A700%7CPlus+Jakarta+Sans%3A700&#038;subset=latin&#038;display=fallback' media='all' />
<link rel='stylesheet' id='apptek-custom-css' href='https://www.adminuiux.com/wp-content/themes/apptek/assets/css/apptek-custom.css?ver=1788624552' media='all' />
<link rel='stylesheet' id='apptek-menu-css' href='https://www.adminuiux.com/wp-content/themes/apptek/assets/css/header-menu.css?ver=1788624552' media='all' />
<link rel='stylesheet' id='apptek-style-css' href='https://www.adminuiux.com/wp-content/themes/apptek/style.css?ver=1788624552' media='all' />
<link rel='stylesheet' id='addtoany-css' href='https://www.adminuiux.com/wp-content/plugins/add-to-any/addtoany.min.css?ver=1.16' media='all' />
<style id="addtoany-inline-css">
@media screen and (max-width:767px){
.a2a_floating_style.a2a_vertical_style{display:none;}
}
/*# sourceURL=addtoany-inline-css */
</style>
<script async data-wp-strategy="async" id="monsterinsights-frontend-script-js" src="https://www.adminuiux.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.min.js?ver=11.2.0"></script>
<script data-cfasync="false" data-wpfc-render="false" id='monsterinsights-frontend-script-js-extra'>var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"doc,pdf,ppt,zip,xls,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/www.adminuiux.com","hash_tracking":"false","v4_id":"G-Z9LSH6MRZR"};</script>
<script id="addtoany-core-js-before">
window.a2a_config=window.a2a_config||{};a2a_config.callbacks=[];a2a_config.overlays=[];a2a_config.templates={};

//# sourceURL=addtoany-core-js-before
</script>
<script id="addtoany-core-js" defer src="https://static.addtoany.com/menu/page.js"></script>
<script id="jquery-core-js" src="https://www.adminuiux.com/wp-includes/js/jquery/jquery.min.js?ver=3.7.1"></script>
<script id="jquery-migrate-js" src="https://www.adminuiux.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1"></script>
<script id="addtoany-jquery-js" defer src="https://www.adminuiux.com/wp-content/plugins/add-to-any/addtoany.min.js?ver=1.1"></script>
<script data-wp-strategy="defer" id="jquery-blockui-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.7.0-wc.9.8.7"></script>
<script id="wc-add-to-cart-js-extra">
var wc_add_to_cart_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https://www.adminuiux.com/?page_id=35477","is_cart":"","cart_redirect_after_add":"yes"};
//# sourceURL=wc-add-to-cart-js-extra
</script>
<script data-wp-strategy="defer" defer id="wc-add-to-cart-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=9.8.7"></script>
<script data-wp-strategy="defer" defer id="js-cookie-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4-wc.9.8.7"></script>
<script id="woocommerce-js-extra">
var woocommerce_params = {"ajax_url":"/wp-admin/admin-ajax.php","wc_ajax_url":"/?wc-ajax=%%endpoint%%","i18n_password_show":"Show password","i18n_password_hide":"Hide password"};
//# sourceURL=woocommerce-js-extra
</script>
<script data-wp-strategy="defer" defer id="woocommerce-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=9.8.7"></script>
<link rel="https://api.w.org/" href="https://www.adminuiux.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://www.adminuiux.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 7.1" />
<meta name="generator" content="WooCommerce 9.8.7" />
<style type='text/css'> .ae_data .elementor-editor-element-setting {
            display:none !important;
            }
            </style>		<script type="text/javascript">
			(function(c, l, a, r, i, t, y) {
				c[a] = c[a] || function() {
					(c[a].q = c[a].q || []).push(arguments)
				};
				t = l.createElement(r);
				t.async = 1;
				t.src = "https://www.clarity.ms/tag/" + i + "?ref=wordpress";
				y = l.getElementsByTagName(r)[0];
				y.parentNode.insertBefore(t, y);
			})(window, document, "clarity", "script", "v9vd37g8vl");
		</script>
			<!--Customizer CSS-->
		<style type="text/css">
			
			
					</style>
		<!--/Customizer CSS-->
			<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Elementor 3.27.7; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://www.adminuiux.com/wp-content/uploads/2022/08/logo-512-150x150.png" sizes="32x32" />
<link rel="icon" href="https://www.adminuiux.com/wp-content/uploads/2022/08/logo-512-300x300.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://www.adminuiux.com/wp-content/uploads/2022/08/logo-512-300x300.png" />
<meta name="msapplication-TileImage" content="https://www.adminuiux.com/wp-content/uploads/2022/08/logo-512-300x300.png" />
<style id="wp-custom-css">

 .all-column-gap .elementor-column-gap-default {
     column-gap: 20px;
}
@media (min-width: 1025px) {
    .all-column-gap .elementor-column-gap-default {
        column-gap: 30px;
    }
}
.blog_main .blog-style-three-item > .holder > .pic > .blog-tag{ padding:4px 4px;border-radius:15px; background-color: #000000 }
.blog_main .blog-style-three-item > .holder > .pic > .blog-tag a{display: inline-block; margin: 4px; padding: 5px 10px; border-radius: 4px; transform: scale(1); border-radius:10px}
.blog_main .blog-style-three-item > .holder > .pic { border-radius:20px; border:1px solid rgba(0, 0, 0, 0.15)}
.blog_main .blog-style-three-item > .holder > .pic > .pic-main img{ width:100%}
.single-post .wraper_blog_main.style-default .blog_single .entry-extra-item .entry-header .entry-title{
	color: #222222;
	margin-bottom:50px !important;
}
.single-post .wraper_blog_main.style-default .blog_single .single-post .entry-extra-item {
    background: rgb(235 227 251) !important;
    padding: 4rem 15% 4rem 15%;
	margin-bottom:50px;
    text-align: center;
}
.single-post .wraper_blog_main.style-default .blog_single .entry-extra-item .date {
    margin: 0px;
    padding-right: 15px;
    text-align: left;
    display: flex;
    column-gap: 20px;
    color: #333222;
    align-items: center;
}
.single-post .wraper_blog_main.style-default .blog_single .entry-extra-item .date p{
	color: #666666
}
.single-post .wraper_blog_main.style-default .blog_single .entry-extra-item .category a {
    color: #000000;
    border-radius: 10px;
    padding: 5px 15px;
    margin: 0 auto;
    text-align: center;
}
.single-post .wraper_blog_main.style-default .blog_single .entry-extra-item .category{
	text-align:center
}
.no-envato{ display:block}
.envato{ display:none}
.yes-envato .no-envato{ display:none}
.yes-envato .envato{ display:block}
</style>
<style id="apptek-customizer-css-inline-css">
h1 {font-family:'Plus Jakarta Sans';font-weight:700 !important;text-transform:capitalize;font-size:3.75em;line-height:1.3em !important;color:#191d27;}h2 {font-family:'Plus Jakarta Sans';font-weight:600 !important;text-transform:capitalize;font-size:2.5em;line-height:1.4em !important;color:#191d27;}h3 {font-family:'Plus Jakarta Sans';font-weight:600 !important;text-transform:capitalize;font-size:1.875em;line-height:1.3em !important;color:#191d27;}h4 {font-family:'Plus Jakarta Sans';font-weight:600 !important;text-transform:capitalize;font-size:1.5em;line-height:1.5em !important;color:#191d27;}h5 {font-family:'Plus Jakarta Sans';font-weight:600 !important;text-transform:capitalize;font-size:1.25em;line-height:1.5em !important;color:#191d27;}h6 {font-family:'Plus Jakarta Sans';font-weight:600 !important;text-transform:capitalize;font-size:1.125em;line-height:1.5em !important;color:#191d27;}body, p {font-family:'Plus Jakarta Sans';font-weight:500 !important;text-transform:none;font-size:1em;line-height:1.75em !important;color:#6b6b6b;}.apptek-button > .apptek-button-main, .apptek-custom-button > .apptek-custom-button-main, .gdpr-notice .btn, .widget-area > .widget.widget_price_filter .button, .post.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .page.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .tribe_events.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .testimonial.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .team.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .portfolio.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .case-studies.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .client.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .product.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn, .comments-area .comment-form > p button[type=submit], .comments-area .comment-form > p button[type=reset], .wraper_error_main.style-one .error_main .btn, .wraper_error_main.style-two .error_main .btn, .wraper_error_main.style-three .error_main_item .btn, .wraper_error_main.style-four .error_main .btn {font-family:'Plus Jakarta Sans',sans-serif;font-weight:500 !important;text-transform:none;font-size:1em;line-height:1.75em !important;background-color:#0e1552;color:#ffffff;padding-top:15px;padding-right:35px;padding-bottom:15px;padding-left:35px;}.apptek-button > .apptek-button-main:hover, .apptek-custom-button > .apptek-custom-button-main:hover, .gdpr-notice .btn:hover,  .widget-area > .widget.widget_price_filter .button:hover, .post.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .page.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .tribe_events.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .testimonial.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .team.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .portfolio.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .case-studies.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .client.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .product.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:before, .comments-area .comment-form > p button[type=reset]:hover, .wraper_error_main.style-one .error_main .btn:hover, .wraper_error_main.style-two .error_main .btn:hover, .wraper_error_main.style-three .error_main_item .btn:hover, .wraper_error_main.style-four .error_main .btn:hover, .post.style-default .entry-main .entry-extra .entry-extra-item .post-read-more .btn:hover span,.widget-area > .widget.widget_search .search-form input[type="submit"]:hover {background-color:#0e1552;color:#ffffff;}.wraper_comingsoon_main {background-color: #eff0f2;}.right-sidebar .widget-area .widget_tag_cloud .tagcloud a, .post-tags a[rel="tag"] {background-color: #1e4ec4;}.single-post .wraper_blog_main.style-default .blog_single .single-post .entry-extra-item{ background: #1e4ec4};body > .scrollup {background-color: #ffffff;}body > .scrollup svg {color: #1e4ec4;}.rt-cursor-dot-outline,.rt-cursor-dot-outline-2 {}.rt-cursor-dot,.rt-cursor-dot-2 {background-color: #dc5656;}@media screen and (max-width: 767px) {body {font-family:'Plus Jakarta Sans',sans-serif;font-weight:500 !important;text-transform:capitalize;}h1 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:700 !important;text-transform:capitalize;font-size:2.5em;}h2 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:600 !important;text-transform:capitalize;font-size:1.875em;}h3 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:700 !important;text-transform:capitalize;}h4 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:700 !important;text-transform:capitalize;}h5 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:700 !important;text-transform:capitalize;}h6 {font-family:'Plus Jakarta Sans',sans-serif;font-weight:700 !important;text-transform:capitalize;}}
/*# sourceURL=apptek-customizer-css-inline-css */
</style>
<link rel='stylesheet' id='elementor-frontend-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/custom-frontend.min.css?ver=1765995456' media='all' />
<link rel='stylesheet' id='elementor-post-36956-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/post-36956.css?ver=1768815781' media='all' />
<link rel='stylesheet' id='rt-menu-style-two-css' href='https://www.adminuiux.com/wp-content/plugins/radiantthemes-addons/widgets/header-nav-menu/css/header-menu-style-two.css?ver=1788624552' media='all' />
<link rel='stylesheet' id='elementor-post-35648-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/post-35648.css?ver=1773646186' media='all' />
<link rel='stylesheet' id='widget-heading-css' href='https://www.adminuiux.com/wp-content/plugins/elementor/assets/css/widget-heading.min.css?ver=3.27.7' media='all' />
<link rel='stylesheet' id='elementor-post-36017-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/post-36017.css?ver=1785909218' media='all' />
<link rel='stylesheet' id='elementor-post-51005-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/post-51005.css?ver=1786014372' media='all' />
<link rel='stylesheet' id='elementor-icons-css' href='https://www.adminuiux.com/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=5.35.0' media='all' />
<link rel='stylesheet' id='elementor-post-7-css' href='https://www.adminuiux.com/wp-content/uploads/elementor/css/post-7.css?ver=1765995456' media='all' />
<link rel='stylesheet' id='font-awesome-5-all-css' href='https://www.adminuiux.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/all.min.css?ver=3.27.7' media='all' />
<link rel='stylesheet' id='font-awesome-4-shim-css' href='https://www.adminuiux.com/wp-content/plugins/elementor/assets/lib/font-awesome/css/v4-shims.min.css?ver=3.27.7' media='all' />
<link rel='stylesheet' id='google-fonts-1-css' href='https://fonts.googleapis.com/css?family=Roboto:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic%7CRoboto+Slab:100,100italic,200,200italic,300,300italic,400,400italic,500,500italic,600,600italic,700,700italic,800,800italic,900,900italic&#038;display=auto&#038;ver=7.1' media='all' />

</head>

<body class="error404 wp-custom-logo wp-embed-responsive wp-theme-apptek theme-apptek woocommerce-no-js woo-variation-swatches wvs-behavior-blur wvs-theme-apptek wvs-show-label wvs-tooltip apptek apptek-apptek hfeed elementor-default elementor-kit-7">
        <!-- overlay -->
    <div class="overlay"></div>
    <!-- overlay -->
   
    <!-- scrollup -->
            <div class="scrollup right">
                    <svg height="20px" id="Layer_1" style="enable-background:new 0 0 512 512;" version="1.1" viewBox="0 0 512 512" width="20px" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <polygon points="396.6,352 416,331.3 256,160 96,331.3 115.3,352 256,201.5 " />
            </svg>
        </div>
                <!-- scrollup -->
                <div class="apptek-website-layout full-width body-inner"><header id="header" class="rt-dark rt-submenu-light"><div class="rt-header-inner">		<div data-elementor-type="section" data-elementor-id="36956" class="elementor elementor-36956">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-28987e04 elementor-section-full_width elementor-section-stretched elementor-section-height-default elementor-section-height-default" data-id="28987e04" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7410509e" data-id="7410509e" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-1d5b8b5c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="1d5b8b5c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-7c76b835" data-id="7c76b835" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-4c2dbb9d elementor-widget elementor-widget-radiant-header_custom_menu" data-id="4c2dbb9d" data-element_type="widget" data-widget_type="radiant-header_custom_menu.default">
				<div class="elementor-widget-container">
							
<div class="cd-user-modal">
    <div class="cd-user-modal-container">
        <ul class="cd-switcher">
            <li><a href="#0">Sign in</a></li>
            <li><a href="#0">Register</a></li>
        </ul>
        <div id="cd-login">
            <!-- log in form -->
            <form class="woocommerce-form woocommerce-form-login login" method="post" >
			<p class="form-row form-row-first">
		<label for="username">Username or email&nbsp;<span class="required">*</span></label>
		<input type="text" class="input-text" name="username" id="username" autocomplete="username" placeholder="Username" />
	</p>
	<p class="form-row form-row-last">
		<label for="password">Password&nbsp;<span class="required">*</span></label>
		<input class="input-text" type="password" name="password" id="password" autocomplete="current-password"  placeholder="Password"/>
	</p>
	<div class="clear"></div>
		<p class="form-row">
		<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
			<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span>Remember me</span>
		</label>
		<input type="hidden" id="woocommerce-login-nonce" name="woocommerce-login-nonce" value="665d2d8067" /><input type="hidden" name="_wp_http_referer" value="/adminuiux/investment-uiux/src/icon.js" />		<input type="hidden" name="redirect" value="#" />
		<span class="lost_password">
		<a href="https://www.adminuiux.com/lost-password/?page_id=35481">Lost your password?</a>
		</span>
	</p>
	<p class="form-actions">
		<button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="Login">Login</button>
	</p>
	<div class="clear"></div>
	</form>        </div>
        <div id="cd-signup">
            <!-- sign up form -->
            <div class="woocommerce-notices-wrapper"></div>	<form method="post" class="woocommerce-form woocommerce-form-register register"  >
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="reg_email">Email address <span class="required">*</span></label>
            <input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" placeholder="Email Address" value="" />		</p>
					<p>A password will be sent to your email address.</p>
				<wc-order-attribution-inputs></wc-order-attribution-inputs><div class="woocommerce-privacy-policy-text"><p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our <a href="https://www.adminuiux.com/privacy-policy/" class="woocommerce-privacy-policy-link" target="_blank">privacy policy</a>.</p>
</div>		<p class="woocommerce-FormRow form-row">
			<input type="hidden" id="woocommerce-register-nonce" name="woocommerce-register-nonce" value="28b34d4079" /><input type="hidden" name="_wp_http_referer" value="/adminuiux/investment-uiux/src/icon.js" />			<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit" name="register" value="Register">Register</button>
		</p>
			</form>
	        </div> <!-- cd-signup -->
        <a href="#0" class="cd-close-form">Close</a>
    </div>
</div>
		<header class="rt-header logo-left  style2 mobile-header-style1 fixed">
            <div class="rt-header-holder rt-box-holder mobile-logo-column">
            
            <div class="logo-holder">
                <div class="logo"><a href="https://www.adminuiux.com"><span class="logo-default"><img src="https://www.adminuiux.com/wp-content/uploads/2022/08/adminuiux-templates.svg" alt="logo" width="210" height="36"></span></a></div>            </div>
            <div class="rt-navbar-menu menu-center">
                <nav class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                    <ul id="menu-main-menu" class="mega-menu"><li id="menu-item-36925" class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-36925 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Web App<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="35648" class="elementor elementor-35648">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-93a51e1 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="93a51e1" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a45e654" data-id="2a45e654" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-e1eed7f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e1eed7f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2e85834" data-id="2e85834" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-187c18a elementor-widget elementor-widget-heading" data-id="187c18a" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Discover Ingenious Designs &amp; Exceptional User Experience</h3>				</div>
				<div class="elementor-element elementor-element-5648d65 elementor-widget elementor-widget-heading" data-id="5648d65" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Dive into a world where creativity meets functionality, and every design is crafted for an outstanding user experience. Bootstrap 5 HTML templates, Angular and Material Angular UI Starter Kit.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-eea7548 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="eea7548" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2ca9a82" data-id="2ca9a82" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-180f43b elementor-widget elementor-widget-heading" data-id="180f43b" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-b7c3550 elementor-widget elementor-widget-heading" data-id="b7c3550" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Bootstrap Template</a></p>				</div>
				<div class="elementor-element elementor-element-0d8a8f4 elementor-widget elementor-widget-heading" data-id="0d8a8f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">InvestmentUIUX Bootstrap HTML</a></p>				</div>
				<div class="elementor-element elementor-element-3853e50 elementor-widget elementor-widget-heading" data-id="3853e50" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-healthcare-clinic-medical-software-ui-kit-template/">Clinical Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-580dc8d elementor-widget elementor-widget-heading" data-id="580dc8d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smarthome-admin-bootstrap-5-themes-dashboard-html-template-smart-home-iot-vehicle-gardening-devices-web-app-ui-kit-template/">SmartHome Bootstrap Themes</a></p>				</div>
				<div class="elementor-element elementor-element-c09dc74 elementor-widget elementor-widget-heading" data-id="c09dc74" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Bootstrap 5 Template</a></p>				</div>
				<div class="elementor-element elementor-element-37c1215 elementor-widget elementor-widget-heading" data-id="37c1215" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-a2492ea elementor-widget elementor-widget-heading" data-id="a2492ea" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/learninguiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-app-ui-kit-template/">Learning  HTML template</a></p>				</div>
				<div class="elementor-element elementor-element-2107f76 elementor-widget elementor-widget-heading" data-id="2107f76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-template-ecommerce-html-inventory-management-software-ui-kit-template/">eCommerce Admin Template</a></p>				</div>
				<div class="elementor-element elementor-element-f731fce elementor-widget elementor-widget-heading" data-id="f731fce" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Admin HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d277e00" data-id="d277e00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-68b31dd elementor-widget elementor-widget-heading" data-id="68b31dd" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Starter Kit</div>				</div>
				<div class="elementor-element elementor-element-a18f819 elementor-widget elementor-widget-heading" data-id="a18f819" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-cee1660 elementor-widget elementor-widget-heading" data-id="cee1660" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX React<sup>19</sup> Dashboard</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-de23d16" data-id="de23d16" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2026946 elementor-widget elementor-widget-heading" data-id="2026946" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-915940d elementor-widget elementor-widget-heading" data-id="915940d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Angular<sup>19</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-02b80d8 elementor-widget elementor-widget-heading" data-id="02b80d8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX <sup>21</sup> Developer UI kit</a></p>				</div>
				<div class="elementor-element elementor-element-f4587c8 elementor-widget elementor-widget-heading" data-id="f4587c8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">Investment Angular<sup>21</sup> Template</a></p>				</div>
				<div class="elementor-element elementor-element-c931b15 elementor-widget elementor-widget-heading" data-id="c931b15" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Angular<sup>20</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-9c157f4 elementor-widget elementor-widget-heading" data-id="9c157f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Angular<sup>14</sup> Admin</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d8a3b31" data-id="d8a3b31" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2b1beed elementor-widget elementor-widget-heading" data-id="2b1beed" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-e88fca3 elementor-widget elementor-widget-heading" data-id="e88fca3" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/material-uiux-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">MaterialUIUX Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-ad7254d elementor-widget elementor-widget-heading" data-id="ad7254d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/smartenergy-angular-material-admin-dashboard-ui-template/">Smart Energy Angular Material</a></p>				</div>
				<div class="elementor-element elementor-element-2314c6c elementor-widget elementor-widget-heading" data-id="2314c6c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/sales-management-saas-dashboard-angular-material-design-admin-template-clean-ui-kit/">Sales Management App</a></p>				</div>
				<div class="elementor-element elementor-element-9ac8ac2 elementor-widget elementor-widget-heading" data-id="9ac8ac2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/saas-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">SaaS Admin Dashboard</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li id="menu-item-46046" class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-46046 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Mobile App<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="36017" class="elementor elementor-36017">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-243c29bc elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="243c29bc" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-57ed66fd" data-id="57ed66fd" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-0de3092 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0de3092" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-889502c" data-id="889502c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-1f071b3 elementor-widget elementor-widget-heading" data-id="1f071b3" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Experience Richness &amp; Modern Trend</h3>				</div>
				<div class="elementor-element elementor-element-d767b48 elementor-widget elementor-widget-heading" data-id="d767b48" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Mobile UI UX App HTML Templates &amp; mobile UI Kit Bootstrap 5 and Angular React UI Starter Kit</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-ecbf8ae elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="ecbf8ae" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-068ca18" data-id="068ca18" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-35d28b9 elementor-widget elementor-widget-heading" data-id="35d28b9" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-a595bf2 elementor-widget elementor-widget-heading" data-id="a595bf2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/fitness-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-fitness-wellness-gym-dieting-mobile-app-ui-kit-template/">Fitness Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-4363351 elementor-widget elementor-widget-heading" data-id="4363351" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smart-home-smartuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-iot-vehicle-gardening-devices-mobile-app-ui-kit-template/">Smart Home Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-813da7d elementor-widget elementor-widget-heading" data-id="813da7d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/8-mobile-finance-wallet-travel-shop-restaurant-app-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-mobile-app-ui-kit-template/">8 Mobile- Eat Travel Wallet</a></p>				</div>
				<div class="elementor-element elementor-element-9062242 elementor-widget elementor-widget-heading" data-id="9062242" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileshop-mobile-html-ecommerce-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">MobileShop App</a></p>				</div>
				<div class="elementor-element elementor-element-5f1c464 elementor-widget elementor-widget-heading" data-id="5f1c464" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular">FinWall Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-fb64092 elementor-widget elementor-widget-heading" data-id="fb64092" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-bootstrap-mobile-html-template/">GoTRI Mobile Dashboard App</a></p>				</div>
				<div class="elementor-element elementor-element-c04f7d9 elementor-widget elementor-widget-heading" data-id="c04f7d9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobile eCommerce App</a></p>				</div>
				<div class="elementor-element elementor-element-04e582e elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="04e582e" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b31ee4c" data-id="b31ee4c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-fdb978b elementor-widget elementor-widget-heading" data-id="fdb978b" data-element_type="widget" data-widget_type="heading.default">
					<h4 class="elementor-heading-title elementor-size-default">&nbsp;</h4>				</div>
				<div class="elementor-element elementor-element-ab75d67 elementor-widget elementor-widget-heading" data-id="ab75d67" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/eshop-uiux-mobile-ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">eCommerce Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-7dbaf3b elementor-widget elementor-widget-heading" data-id="7dbaf3b" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-healthcare-clinic-medical-mobile-app-ui-kit-template/">Clinical Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-29f759c elementor-widget elementor-widget-heading" data-id="29f759c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobile-learninguiux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-mobile-app-ui-kit-template/">Learning Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-92791ba elementor-widget elementor-widget-heading" data-id="92791ba" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/one-ui-ux-multipurpose-mobile-html-template-for-food-wallet-finance-clinic-hospital-shopping-and-ecommerce/">One UI/UX Multipurpose App</a></p>				</div>
				<div class="elementor-element elementor-element-cd47cd5 elementor-widget elementor-widget-heading" data-id="cd47cd5" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile HTML </a></p>				</div>
				<div class="elementor-element elementor-element-7324896 elementor-widget elementor-widget-heading" data-id="7324896" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/soroniuiux-mobile-html-template-with-bootstrap-5/">SoroniUIUX Bootstrap 5 HTML </a></p>				</div>
				<div class="elementor-element elementor-element-6397559 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="6397559" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose HTML</a></p>				</div>
				<div class="elementor-element elementor-element-2b718c4 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="2b718c4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7c24fb7" data-id="7c24fb7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9d37e27 elementor-widget elementor-widget-heading" data-id="9d37e27" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap + Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f008c2d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f008c2d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-1754db9 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="1754db9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investment-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-finance-wallet-investment-mobile-app-ui-kit-template/">Investment Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-576b655 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="576b655" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose A<sup>22</sup></a></p>				</div>
				<div class="elementor-element elementor-element-b02c8b7 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="b02c8b7" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-0496c4a elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="0496c4a" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">FinWall Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-3167424 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="3167424" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3f9c1a9" data-id="3f9c1a9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-faef871 elementor-widget elementor-widget-heading" data-id="faef871" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-44cca76 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="44cca76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/mobile-material-uiux-angular-frontend-ui-kit-template/">MaterialUIUX  A<sup>22</sup> </a></p>				</div>
				<div class="elementor-element elementor-element-1179a51 elementor-widget elementor-widget-heading" data-id="1179a51" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f924d36 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f924d36" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-39f80ca elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="39f80ca" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/overuiux-framework-7-react-mobile-html-template/">OverUIUX Framework7 Utility R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-9fd2f3d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="9fd2f3d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobileUX eCommerce  R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-546629f elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="546629f" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">Finance Wallet App R<sup>19</sup></a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li id="menu-item-51008" class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-51008 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Starter Kit<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="51005" class="elementor elementor-51005">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-53b1c43 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="53b1c43" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-cc698d5" data-id="cc698d5" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-44b675b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="44b675b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-9fc80e2" data-id="9fc80e2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e14e167 elementor-widget elementor-widget-heading" data-id="e14e167" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Best Bootstrap, Angular and React Framework templates</h3>				</div>
				<div class="elementor-element elementor-element-ce7b5f6 elementor-widget elementor-widget-heading" data-id="ce7b5f6" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Launch faster with our high-quality Angular UI Starter Kits, React Starter Kit and Bootstrap 5 templates for both web and mobile apps.<br>Get the perfect UI/UX solution for your SaaS, B2B, Intranet, or universal app projects today.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-085fe24 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="085fe24" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4eca291" data-id="4eca291" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f316a76 elementor-widget elementor-widget-heading" data-id="f316a76" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-fe93d4c elementor-widget elementor-widget-heading" data-id="fe93d4c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-53dbc6b" data-id="53dbc6b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9331c28 elementor-widget elementor-widget-heading" data-id="9331c28" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-524af73 elementor-widget elementor-widget-heading" data-id="524af73" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="#">Coming Soon</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c67c7af" data-id="c67c7af" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-79be140 elementor-widget elementor-widget-heading" data-id="79be140" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f9f0f7c elementor-widget elementor-widget-heading" data-id="f9f0f7c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management React<sup>19.2</sup></a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b68f2f1" data-id="b68f2f1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d458b15 elementor-widget elementor-widget-heading" data-id="d458b15" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-5149966 elementor-widget elementor-widget-heading" data-id="5149966" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/pandemic-tracker-the-free-angular-material-admin-dashboard-template/">Pandemic Tracker</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li id="menu-item-43291" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-43291"><a  href="https://www.adminuiux.com/blog/" data-description="">Blog<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a></li>
</ul>                </nav>
            </div>
            <div class="rt-search-cart-holder">
                  
                                <div class="rt-search-cart-inner-holder">
                 
                
                                                        </div>
                                <div class="rt-social-section">
                                        <ul>
                                                <li class="facebook"><a  href="https://www.facebook.com/adminuiux1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
  <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
</svg></a></li>
                                                                        <li class="twitter"><a  href=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
  <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"/>
</svg></a></li>
                                                                        <li class="linkedin"><a  href="https://www.linkedin.com/company/adminuiux/"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
  <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854zm4.943 12.248V6.169H2.542v7.225zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248S2.4 3.226 2.4 3.934c0 .694.521 1.248 1.327 1.248zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016l.016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225z"/>
</svg></a></li>
                                                                        <li class="instagram"><a  href="https://www.instagram.com/adminuiux"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
  <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
</svg></a></li>
                                            </ul>
                </div>
                                                                                    <div class="menu-icon rt-mobile-hamburger rt-column hidden-lg">
                    <div class="rt-mobile-toggle-holder">
                        <div class="rt-mobile-toggle">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                </div>
 </div>               
</div>
</header>
<header class="rt-header logo-left  style2 mobile-header-style1">
    <div class="rt-header-holder mobile-logo-column">

        <div class="logo-holder">
            <div class="logo"><a href="https://www.adminuiux.com"><span class="logo-default"><img src="https://www.adminuiux.com/wp-content/uploads/2022/08/adminuiux-templates.svg" alt="logo" width="210" height="36"></span></a></div>        </div><!--logo-holder-->
        <div class="rt-navbar-menu menu-center">
            <nav class="apr-nav-menu--main apr-nav-menu--layout-horizontal hover-underline e--pointer-none">
                <ul id="menu-main-menu-1" class="mega-menu"><li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-36925 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Web App<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="35648" class="elementor elementor-35648">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-93a51e1 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="93a51e1" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a45e654" data-id="2a45e654" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-e1eed7f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e1eed7f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2e85834" data-id="2e85834" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-187c18a elementor-widget elementor-widget-heading" data-id="187c18a" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Discover Ingenious Designs &amp; Exceptional User Experience</h3>				</div>
				<div class="elementor-element elementor-element-5648d65 elementor-widget elementor-widget-heading" data-id="5648d65" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Dive into a world where creativity meets functionality, and every design is crafted for an outstanding user experience. Bootstrap 5 HTML templates, Angular and Material Angular UI Starter Kit.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-eea7548 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="eea7548" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2ca9a82" data-id="2ca9a82" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-180f43b elementor-widget elementor-widget-heading" data-id="180f43b" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-b7c3550 elementor-widget elementor-widget-heading" data-id="b7c3550" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Bootstrap Template</a></p>				</div>
				<div class="elementor-element elementor-element-0d8a8f4 elementor-widget elementor-widget-heading" data-id="0d8a8f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">InvestmentUIUX Bootstrap HTML</a></p>				</div>
				<div class="elementor-element elementor-element-3853e50 elementor-widget elementor-widget-heading" data-id="3853e50" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-healthcare-clinic-medical-software-ui-kit-template/">Clinical Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-580dc8d elementor-widget elementor-widget-heading" data-id="580dc8d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smarthome-admin-bootstrap-5-themes-dashboard-html-template-smart-home-iot-vehicle-gardening-devices-web-app-ui-kit-template/">SmartHome Bootstrap Themes</a></p>				</div>
				<div class="elementor-element elementor-element-c09dc74 elementor-widget elementor-widget-heading" data-id="c09dc74" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Bootstrap 5 Template</a></p>				</div>
				<div class="elementor-element elementor-element-37c1215 elementor-widget elementor-widget-heading" data-id="37c1215" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-a2492ea elementor-widget elementor-widget-heading" data-id="a2492ea" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/learninguiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-app-ui-kit-template/">Learning  HTML template</a></p>				</div>
				<div class="elementor-element elementor-element-2107f76 elementor-widget elementor-widget-heading" data-id="2107f76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-template-ecommerce-html-inventory-management-software-ui-kit-template/">eCommerce Admin Template</a></p>				</div>
				<div class="elementor-element elementor-element-f731fce elementor-widget elementor-widget-heading" data-id="f731fce" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Admin HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d277e00" data-id="d277e00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-68b31dd elementor-widget elementor-widget-heading" data-id="68b31dd" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Starter Kit</div>				</div>
				<div class="elementor-element elementor-element-a18f819 elementor-widget elementor-widget-heading" data-id="a18f819" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-cee1660 elementor-widget elementor-widget-heading" data-id="cee1660" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX React<sup>19</sup> Dashboard</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-de23d16" data-id="de23d16" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2026946 elementor-widget elementor-widget-heading" data-id="2026946" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-915940d elementor-widget elementor-widget-heading" data-id="915940d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Angular<sup>19</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-02b80d8 elementor-widget elementor-widget-heading" data-id="02b80d8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX <sup>21</sup> Developer UI kit</a></p>				</div>
				<div class="elementor-element elementor-element-f4587c8 elementor-widget elementor-widget-heading" data-id="f4587c8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">Investment Angular<sup>21</sup> Template</a></p>				</div>
				<div class="elementor-element elementor-element-c931b15 elementor-widget elementor-widget-heading" data-id="c931b15" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Angular<sup>20</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-9c157f4 elementor-widget elementor-widget-heading" data-id="9c157f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Angular<sup>14</sup> Admin</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d8a3b31" data-id="d8a3b31" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2b1beed elementor-widget elementor-widget-heading" data-id="2b1beed" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-e88fca3 elementor-widget elementor-widget-heading" data-id="e88fca3" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/material-uiux-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">MaterialUIUX Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-ad7254d elementor-widget elementor-widget-heading" data-id="ad7254d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/smartenergy-angular-material-admin-dashboard-ui-template/">Smart Energy Angular Material</a></p>				</div>
				<div class="elementor-element elementor-element-2314c6c elementor-widget elementor-widget-heading" data-id="2314c6c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/sales-management-saas-dashboard-angular-material-design-admin-template-clean-ui-kit/">Sales Management App</a></p>				</div>
				<div class="elementor-element elementor-element-9ac8ac2 elementor-widget elementor-widget-heading" data-id="9ac8ac2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/saas-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">SaaS Admin Dashboard</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-46046 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Mobile App<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="36017" class="elementor elementor-36017">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-243c29bc elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="243c29bc" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-57ed66fd" data-id="57ed66fd" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-0de3092 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0de3092" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-889502c" data-id="889502c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-1f071b3 elementor-widget elementor-widget-heading" data-id="1f071b3" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Experience Richness &amp; Modern Trend</h3>				</div>
				<div class="elementor-element elementor-element-d767b48 elementor-widget elementor-widget-heading" data-id="d767b48" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Mobile UI UX App HTML Templates &amp; mobile UI Kit Bootstrap 5 and Angular React UI Starter Kit</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-ecbf8ae elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="ecbf8ae" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-068ca18" data-id="068ca18" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-35d28b9 elementor-widget elementor-widget-heading" data-id="35d28b9" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-a595bf2 elementor-widget elementor-widget-heading" data-id="a595bf2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/fitness-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-fitness-wellness-gym-dieting-mobile-app-ui-kit-template/">Fitness Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-4363351 elementor-widget elementor-widget-heading" data-id="4363351" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smart-home-smartuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-iot-vehicle-gardening-devices-mobile-app-ui-kit-template/">Smart Home Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-813da7d elementor-widget elementor-widget-heading" data-id="813da7d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/8-mobile-finance-wallet-travel-shop-restaurant-app-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-mobile-app-ui-kit-template/">8 Mobile- Eat Travel Wallet</a></p>				</div>
				<div class="elementor-element elementor-element-9062242 elementor-widget elementor-widget-heading" data-id="9062242" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileshop-mobile-html-ecommerce-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">MobileShop App</a></p>				</div>
				<div class="elementor-element elementor-element-5f1c464 elementor-widget elementor-widget-heading" data-id="5f1c464" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular">FinWall Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-fb64092 elementor-widget elementor-widget-heading" data-id="fb64092" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-bootstrap-mobile-html-template/">GoTRI Mobile Dashboard App</a></p>				</div>
				<div class="elementor-element elementor-element-c04f7d9 elementor-widget elementor-widget-heading" data-id="c04f7d9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobile eCommerce App</a></p>				</div>
				<div class="elementor-element elementor-element-04e582e elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="04e582e" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b31ee4c" data-id="b31ee4c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-fdb978b elementor-widget elementor-widget-heading" data-id="fdb978b" data-element_type="widget" data-widget_type="heading.default">
					<h4 class="elementor-heading-title elementor-size-default">&nbsp;</h4>				</div>
				<div class="elementor-element elementor-element-ab75d67 elementor-widget elementor-widget-heading" data-id="ab75d67" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/eshop-uiux-mobile-ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">eCommerce Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-7dbaf3b elementor-widget elementor-widget-heading" data-id="7dbaf3b" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-healthcare-clinic-medical-mobile-app-ui-kit-template/">Clinical Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-29f759c elementor-widget elementor-widget-heading" data-id="29f759c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobile-learninguiux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-mobile-app-ui-kit-template/">Learning Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-92791ba elementor-widget elementor-widget-heading" data-id="92791ba" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/one-ui-ux-multipurpose-mobile-html-template-for-food-wallet-finance-clinic-hospital-shopping-and-ecommerce/">One UI/UX Multipurpose App</a></p>				</div>
				<div class="elementor-element elementor-element-cd47cd5 elementor-widget elementor-widget-heading" data-id="cd47cd5" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile HTML </a></p>				</div>
				<div class="elementor-element elementor-element-7324896 elementor-widget elementor-widget-heading" data-id="7324896" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/soroniuiux-mobile-html-template-with-bootstrap-5/">SoroniUIUX Bootstrap 5 HTML </a></p>				</div>
				<div class="elementor-element elementor-element-6397559 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="6397559" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose HTML</a></p>				</div>
				<div class="elementor-element elementor-element-2b718c4 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="2b718c4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7c24fb7" data-id="7c24fb7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9d37e27 elementor-widget elementor-widget-heading" data-id="9d37e27" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap + Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f008c2d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f008c2d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-1754db9 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="1754db9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investment-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-finance-wallet-investment-mobile-app-ui-kit-template/">Investment Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-576b655 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="576b655" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose A<sup>22</sup></a></p>				</div>
				<div class="elementor-element elementor-element-b02c8b7 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="b02c8b7" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-0496c4a elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="0496c4a" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">FinWall Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-3167424 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="3167424" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3f9c1a9" data-id="3f9c1a9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-faef871 elementor-widget elementor-widget-heading" data-id="faef871" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-44cca76 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="44cca76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/mobile-material-uiux-angular-frontend-ui-kit-template/">MaterialUIUX  A<sup>22</sup> </a></p>				</div>
				<div class="elementor-element elementor-element-1179a51 elementor-widget elementor-widget-heading" data-id="1179a51" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f924d36 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f924d36" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-39f80ca elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="39f80ca" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/overuiux-framework-7-react-mobile-html-template/">OverUIUX Framework7 Utility R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-9fd2f3d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="9fd2f3d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobileUX eCommerce  R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-546629f elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="546629f" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">Finance Wallet App R<sup>19</sup></a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-51008 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Starter Kit<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="51005" class="elementor elementor-51005">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-53b1c43 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="53b1c43" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-cc698d5" data-id="cc698d5" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-44b675b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="44b675b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-9fc80e2" data-id="9fc80e2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e14e167 elementor-widget elementor-widget-heading" data-id="e14e167" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Best Bootstrap, Angular and React Framework templates</h3>				</div>
				<div class="elementor-element elementor-element-ce7b5f6 elementor-widget elementor-widget-heading" data-id="ce7b5f6" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Launch faster with our high-quality Angular UI Starter Kits, React Starter Kit and Bootstrap 5 templates for both web and mobile apps.<br>Get the perfect UI/UX solution for your SaaS, B2B, Intranet, or universal app projects today.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-085fe24 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="085fe24" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4eca291" data-id="4eca291" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f316a76 elementor-widget elementor-widget-heading" data-id="f316a76" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-fe93d4c elementor-widget elementor-widget-heading" data-id="fe93d4c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-53dbc6b" data-id="53dbc6b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9331c28 elementor-widget elementor-widget-heading" data-id="9331c28" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-524af73 elementor-widget elementor-widget-heading" data-id="524af73" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="#">Coming Soon</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c67c7af" data-id="c67c7af" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-79be140 elementor-widget elementor-widget-heading" data-id="79be140" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f9f0f7c elementor-widget elementor-widget-heading" data-id="f9f0f7c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management React<sup>19.2</sup></a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b68f2f1" data-id="b68f2f1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d458b15 elementor-widget elementor-widget-heading" data-id="d458b15" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-5149966 elementor-widget elementor-widget-heading" data-id="5149966" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/pandemic-tracker-the-free-angular-material-admin-dashboard-template/">Pandemic Tracker</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-43291"><a  href="https://www.adminuiux.com/blog/" data-description="">Blog<span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a></li>
</ul>            </nav>
        </div><!--rt-navbar-menu-->
        <div class="rt-search-cart-holder">
              
                         
            <div class="rt-search-cart-inner-holder">
                 
                                            </div>
                        <div class="rt-social-section">
                                <ul>
                                        <li class="facebook"><a  href="https://www.facebook.com/adminuiux1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
  <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
</svg></a></li>
                                                            <li class="twitter"><a  href=""><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-twitter-x" viewBox="0 0 16 16">
  <path d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865z"/>
</svg></a></li>
                                                            <li class="linkedin"><a  href="https://www.linkedin.com/company/adminuiux/"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-linkedin" viewBox="0 0 16 16">
  <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854zm4.943 12.248V6.169H2.542v7.225zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248S2.4 3.226 2.4 3.934c0 .694.521 1.248 1.327 1.248zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016l.016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225z"/>
</svg></a></li>
                                                            <li class="instagram"><a  href="https://www.instagram.com/adminuiux"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
  <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
</svg></a></li>
                                    </ul>
            </div>
                                                                        <div class="menu-icon rt-mobile-hamburger rt-column hidden-lg">
                <div class="rt-mobile-toggle-holder">
                    <div class="rt-mobile-toggle">
                        <span></span><span></span><span></span>
                    </div>
                </div>
            </div>
</div>
</div>
</header><!--rt-header-->
<nav id="mobile-menu" class="side-panel">
    <header class="side-panel-header">
        <span><img src="https://www.adminuiux.com/wp-content/uploads/2022/08/adminuiux-templates.svg" alt="logo" width="210" height="36"></span>
        <div class="rt-toggle-close rt-close-btn" title="Close"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" x="0" y="0" width="12" height="12" viewBox="1.1 1.1 12 12" enable-background="new 1.1 1.1 12 12" xml:space="preserve">
                <path d="M8.3 7.1l4.6-4.6c0.3-0.3 0.3-0.8 0-1.2 -0.3-0.3-0.8-0.3-1.2 0L7.1 5.9 2.5 1.3c-0.3-0.3-0.8-0.3-1.2 0 -0.3 0.3-0.3 0.8 0 1.2L5.9 7.1l-4.6 4.6c-0.3 0.3-0.3 0.8 0 1.2s0.8 0.3 1.2 0L7.1 8.3l4.6 4.6c0.3 0.3 0.8 0.3 1.2 0 0.3-0.3 0.3-0.8 0-1.2L8.3 7.1z"></path>
            </svg></div>
    </header>
    <div class="side-panel-inner mobile-side-panel-inner">
        <div class="mobile-menu-top">
                        <ul id="menu-main-menu-2" class="rt-mobile-menu"><li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-36925 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Web App<span></span><span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="35648" class="elementor elementor-35648">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-93a51e1 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="93a51e1" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2a45e654" data-id="2a45e654" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-e1eed7f elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="e1eed7f" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-2e85834" data-id="2e85834" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-187c18a elementor-widget elementor-widget-heading" data-id="187c18a" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Discover Ingenious Designs &amp; Exceptional User Experience</h3>				</div>
				<div class="elementor-element elementor-element-5648d65 elementor-widget elementor-widget-heading" data-id="5648d65" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Dive into a world where creativity meets functionality, and every design is crafted for an outstanding user experience. Bootstrap 5 HTML templates, Angular and Material Angular UI Starter Kit.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-eea7548 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="eea7548" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2ca9a82" data-id="2ca9a82" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-180f43b elementor-widget elementor-widget-heading" data-id="180f43b" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-b7c3550 elementor-widget elementor-widget-heading" data-id="b7c3550" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Bootstrap Template</a></p>				</div>
				<div class="elementor-element elementor-element-0d8a8f4 elementor-widget elementor-widget-heading" data-id="0d8a8f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">InvestmentUIUX Bootstrap HTML</a></p>				</div>
				<div class="elementor-element elementor-element-3853e50 elementor-widget elementor-widget-heading" data-id="3853e50" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-healthcare-clinic-medical-software-ui-kit-template/">Clinical Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-580dc8d elementor-widget elementor-widget-heading" data-id="580dc8d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smarthome-admin-bootstrap-5-themes-dashboard-html-template-smart-home-iot-vehicle-gardening-devices-web-app-ui-kit-template/">SmartHome Bootstrap Themes</a></p>				</div>
				<div class="elementor-element elementor-element-c09dc74 elementor-widget elementor-widget-heading" data-id="c09dc74" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Bootstrap 5 Template</a></p>				</div>
				<div class="elementor-element elementor-element-37c1215 elementor-widget elementor-widget-heading" data-id="37c1215" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-a2492ea elementor-widget elementor-widget-heading" data-id="a2492ea" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/learninguiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-app-ui-kit-template/">Learning  HTML template</a></p>				</div>
				<div class="elementor-element elementor-element-2107f76 elementor-widget elementor-widget-heading" data-id="2107f76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-template-ecommerce-html-inventory-management-software-ui-kit-template/">eCommerce Admin Template</a></p>				</div>
				<div class="elementor-element elementor-element-f731fce elementor-widget elementor-widget-heading" data-id="f731fce" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Admin HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d277e00" data-id="d277e00" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-68b31dd elementor-widget elementor-widget-heading" data-id="68b31dd" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Starter Kit</div>				</div>
				<div class="elementor-element elementor-element-a18f819 elementor-widget elementor-widget-heading" data-id="a18f819" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX Developer Dashboards</a></p>				</div>
				<div class="elementor-element elementor-element-cee1660 elementor-widget elementor-widget-heading" data-id="cee1660" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX React<sup>19</sup> Dashboard</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-de23d16" data-id="de23d16" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2026946 elementor-widget elementor-widget-heading" data-id="2026946" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-915940d elementor-widget elementor-widget-heading" data-id="915940d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Angular<sup>19</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-02b80d8 elementor-widget elementor-widget-heading" data-id="02b80d8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-the-ultimate-multipurpose-bootstrap-5-dashboard-template-with-angular-and-reactjs-starter-ui-kit/">DevUIUX <sup>21</sup> Developer UI kit</a></p>				</div>
				<div class="elementor-element elementor-element-f4587c8 elementor-widget elementor-widget-heading" data-id="f4587c8" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investmentuiux-admin-ui-ux-bootstrap-5-themes-dashboard-html-template-investment-finance-tracking-software-ui-kit-template/">Investment Angular<sup>21</sup> Template</a></p>				</div>
				<div class="elementor-element elementor-element-c931b15 elementor-widget elementor-widget-heading" data-id="c931b15" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-admin-dashboard-bootstrap-html-template-with-angular-ui-ux-starter-kit/">GoTRI Angular<sup>20</sup> Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-9c157f4 elementor-widget elementor-widget-heading" data-id="9c157f4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/windoors-finance-investment-inventory-networking-bootstrap-dashboard-html-template/">Windoors Angular<sup>14</sup> Admin</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-d8a3b31" data-id="d8a3b31" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-2b1beed elementor-widget elementor-widget-heading" data-id="2b1beed" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-e88fca3 elementor-widget elementor-widget-heading" data-id="e88fca3" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/material-uiux-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">MaterialUIUX Admin Dashboard</a></p>				</div>
				<div class="elementor-element elementor-element-ad7254d elementor-widget elementor-widget-heading" data-id="ad7254d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/smartenergy-angular-material-admin-dashboard-ui-template/">Smart Energy Angular Material</a></p>				</div>
				<div class="elementor-element elementor-element-2314c6c elementor-widget elementor-widget-heading" data-id="2314c6c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/sales-management-saas-dashboard-angular-material-design-admin-template-clean-ui-kit/">Sales Management App</a></p>				</div>
				<div class="elementor-element elementor-element-9ac8ac2 elementor-widget elementor-widget-heading" data-id="9ac8ac2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/saas-admin-dashboard-frontend-ui-kit-template-designed-with-material-angular-design/">SaaS Admin Dashboard</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-46046 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Mobile App<span></span><span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="36017" class="elementor elementor-36017">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-243c29bc elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="243c29bc" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-57ed66fd" data-id="57ed66fd" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-0de3092 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="0de3092" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-889502c" data-id="889502c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-1f071b3 elementor-widget elementor-widget-heading" data-id="1f071b3" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Experience Richness &amp; Modern Trend</h3>				</div>
				<div class="elementor-element elementor-element-d767b48 elementor-widget elementor-widget-heading" data-id="d767b48" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Mobile UI UX App HTML Templates &amp; mobile UI Kit Bootstrap 5 and Angular React UI Starter Kit</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-ecbf8ae elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="ecbf8ae" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-068ca18" data-id="068ca18" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-35d28b9 elementor-widget elementor-widget-heading" data-id="35d28b9" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-a595bf2 elementor-widget elementor-widget-heading" data-id="a595bf2" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/fitness-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-fitness-wellness-gym-dieting-mobile-app-ui-kit-template/">Fitness Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-4363351 elementor-widget elementor-widget-heading" data-id="4363351" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/smart-home-smartuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-iot-vehicle-gardening-devices-mobile-app-ui-kit-template/">Smart Home Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-813da7d elementor-widget elementor-widget-heading" data-id="813da7d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/8-mobile-finance-wallet-travel-shop-restaurant-app-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-mobile-app-ui-kit-template/">8 Mobile- Eat Travel Wallet</a></p>				</div>
				<div class="elementor-element elementor-element-9062242 elementor-widget elementor-widget-heading" data-id="9062242" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileshop-mobile-html-ecommerce-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">MobileShop App</a></p>				</div>
				<div class="elementor-element elementor-element-5f1c464 elementor-widget elementor-widget-heading" data-id="5f1c464" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular">FinWall Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-fb64092 elementor-widget elementor-widget-heading" data-id="fb64092" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/gotri-bootstrap-mobile-html-template/">GoTRI Mobile Dashboard App</a></p>				</div>
				<div class="elementor-element elementor-element-c04f7d9 elementor-widget elementor-widget-heading" data-id="c04f7d9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobile eCommerce App</a></p>				</div>
				<div class="elementor-element elementor-element-04e582e elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="04e582e" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b31ee4c" data-id="b31ee4c" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-fdb978b elementor-widget elementor-widget-heading" data-id="fdb978b" data-element_type="widget" data-widget_type="heading.default">
					<h4 class="elementor-heading-title elementor-size-default">&nbsp;</h4>				</div>
				<div class="elementor-element elementor-element-ab75d67 elementor-widget elementor-widget-heading" data-id="ab75d67" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/eshop-uiux-mobile-ecommerce-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-inventory-ecommerce-shopping-mobile-app-ui-kit-template/">eCommerce Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-7dbaf3b elementor-widget elementor-widget-heading" data-id="7dbaf3b" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/digiclinicuiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-healthcare-clinic-medical-mobile-app-ui-kit-template/">Clinical Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-29f759c elementor-widget elementor-widget-heading" data-id="29f759c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobile-learninguiux-bootstrap-5-themes-dashboard-html-template-e-learning-online-learning-courses-mobile-app-ui-kit-template/">Learning Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-92791ba elementor-widget elementor-widget-heading" data-id="92791ba" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/one-ui-ux-multipurpose-mobile-html-template-for-food-wallet-finance-clinic-hospital-shopping-and-ecommerce/">One UI/UX Multipurpose App</a></p>				</div>
				<div class="elementor-element elementor-element-cd47cd5 elementor-widget elementor-widget-heading" data-id="cd47cd5" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile HTML </a></p>				</div>
				<div class="elementor-element elementor-element-7324896 elementor-widget elementor-widget-heading" data-id="7324896" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/soroniuiux-mobile-html-template-with-bootstrap-5/">SoroniUIUX Bootstrap 5 HTML </a></p>				</div>
				<div class="elementor-element elementor-element-6397559 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="6397559" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose HTML</a></p>				</div>
				<div class="elementor-element elementor-element-2b718c4 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="2b718c4" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App HTML</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-7c24fb7" data-id="7c24fb7" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9d37e27 elementor-widget elementor-widget-heading" data-id="9d37e27" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap + Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f008c2d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f008c2d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/adminux-mobile-ui-ux-bootstrap-5-themes-mobile-dashboard-html-template-multipurpose-clean-ui-kit-template-angular/">AdminUX Mobile App</a></p>				</div>
				<div class="elementor-element elementor-element-1754db9 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="1754db9" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/investment-uiux-mobile-admin-ui-ux-bootstrap-5-themes-dashboard-mobile-html-template-finance-wallet-investment-mobile-app-ui-kit-template/">Investment Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-576b655 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="576b655" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/adminuiux-dashboard-templates-bootstrap-5-framework-admin-dashboard-html-templates/mobileux-multipurpose-html-wallet-finance-ecommerce-bootstrap-5-themes-admin-dashboard-mobile-html-template-and-mobile-app-ui-kit/">MobileUX Multipurpose A<sup>22</sup></a></p>				</div>
				<div class="elementor-element elementor-element-b02c8b7 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="b02c8b7" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-0496c4a elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="0496c4a" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">FinWall Mobile App A<sup>21</sup></a></p>				</div>
				<div class="elementor-element elementor-element-3167424 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="3167424" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/fimobile-html-app-template-for-finance-and-investment-built-with-bootstrap-5-angular-12-framework7-v6/">Fimobile Finance App</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3f9c1a9" data-id="3f9c1a9" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-faef871 elementor-widget elementor-widget-heading" data-id="faef871" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-44cca76 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="44cca76" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/mobile-material-uiux-angular-frontend-ui-kit-template/">MaterialUIUX  A<sup>22</sup> </a></p>				</div>
				<div class="elementor-element elementor-element-1179a51 elementor-widget elementor-widget-heading" data-id="1179a51" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f924d36 elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="f924d36" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/devuiux-mobile-dashboard-template-for-developer-with-bootstrap-5-html-angular-and-react-js/">DevUIUX Mobile Dashboard R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-39f80ca elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="39f80ca" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/overuiux-framework-7-react-mobile-html-template/">OverUIUX Framework7 Utility R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-9fd2f3d elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="9fd2f3d" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/go-mobile-ux-multipurpose-mobile-html-template-bootstrap-5-mobile-ecommerce-shop/">GoMobileUX eCommerce  R<sup>19</sup></a></p>				</div>
				<div class="elementor-element elementor-element-546629f elementor-widget__width-inherit elementor-widget elementor-widget-heading" data-id="546629f" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/finwallapp-finance-wallet-mobile-html-template-bootstrap-5-framework7-angular/">Finance Wallet App R<sup>19</sup></a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-mega_menu menu-item-51008 menu-item-has-children  menu-item-mega-parent"><a  href="#" data-description="">Starter Kit<span></span><span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a><ul class="sub-menu"><li class="mega-menu-content">		<div data-elementor-type="wp-post" data-elementor-id="51005" class="elementor elementor-51005">
						<section class="elementor-section elementor-top-section elementor-element elementor-element-53b1c43 elementor-section-stretched mega-menu-section elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="53b1c43" data-element_type="section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-cc698d5" data-id="cc698d5" data-element_type="column" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
			<div class="elementor-widget-wrap elementor-element-populated">
						<section class="elementor-section elementor-inner-section elementor-element elementor-element-44b675b elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="44b675b" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-9fc80e2" data-id="9fc80e2" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-e14e167 elementor-widget elementor-widget-heading" data-id="e14e167" data-element_type="widget" data-widget_type="heading.default">
					<h3 class="elementor-heading-title elementor-size-default">Best Bootstrap, Angular and React Framework templates</h3>				</div>
				<div class="elementor-element elementor-element-ce7b5f6 elementor-widget elementor-widget-heading" data-id="ce7b5f6" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default">Launch faster with our high-quality Angular UI Starter Kits, React Starter Kit and Bootstrap 5 templates for both web and mobile apps.<br>Get the perfect UI/UX solution for your SaaS, B2B, Intranet, or universal app projects today.</p>				</div>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-inner-section elementor-element elementor-element-085fe24 elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="085fe24" data-element_type="section" data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-4eca291" data-id="4eca291" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-f316a76 elementor-widget elementor-widget-heading" data-id="f316a76" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">HTML Template</div>				</div>
				<div class="elementor-element elementor-element-fe93d4c elementor-widget elementor-widget-heading" data-id="fe93d4c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-53dbc6b" data-id="53dbc6b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-9331c28 elementor-widget elementor-widget-heading" data-id="9331c28" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap Angular UI Kit</div>				</div>
				<div class="elementor-element elementor-element-524af73 elementor-widget elementor-widget-heading" data-id="524af73" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="#">Coming Soon</a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c67c7af" data-id="c67c7af" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-79be140 elementor-widget elementor-widget-heading" data-id="79be140" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Bootstrap React UI Kit</div>				</div>
				<div class="elementor-element elementor-element-f9f0f7c elementor-widget elementor-widget-heading" data-id="f9f0f7c" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/wealth-ui-ux-free-bootstrap-dashboard-html-template/">Wealth Management React<sup>19.2</sup></a></p>				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-b68f2f1" data-id="b68f2f1" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-d458b15 elementor-widget elementor-widget-heading" data-id="d458b15" data-element_type="widget" data-widget_type="heading.default">
					<div class="elementor-heading-title elementor-size-default">Material Angular UI kit</div>				</div>
				<div class="elementor-element elementor-element-5149966 elementor-widget elementor-widget-heading" data-id="5149966" data-element_type="widget" data-widget_type="heading.default">
					<p class="elementor-heading-title elementor-size-default"><a href="https://www.adminuiux.com/pandemic-tracker-the-free-angular-material-admin-dashboard-template/">Pandemic Tracker</a></p>				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				</div>
		</li></ul></li>
<li class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-43291"><a  href="https://www.adminuiux.com/blog/" data-description="">Blog<span></span><span class="arrow"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg></span></a></li>
</ul>            <div class="rt-search-cart-holder">           
                      
                        <div class="rt-social-section">
                                <ul>
                                        <li class="facebook"><a  href="https://www.facebook.com/adminuiux1"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="17" height="17" viewBox="0 0 17 17">
                                <path d="M12.461 5.57l-0.309 2.93h-2.342v8.5h-3.518v-8.5h-1.753v-2.93h1.753v-1.764c0-2.383 0.991-3.806 3.808-3.806h2.341v2.93h-1.465c-1.093 0-1.166 0.413-1.166 1.176v1.464h2.651z" fill="" />
                            </svg></a></li>
                                                            <li class="twitter"><a  href="https://x.com/admiinuiux"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="17" height="17" viewBox="0 0 17 17">
                                <path d="M15.253 5.038c0.011 0.151 0.011 0.302 0.011 0.454 0 4.605-3.506 9.912-9.913 9.912-1.974 0-3.808-0.572-5.351-1.564 0.281 0.032 0.551 0.042 0.842 0.042 1.629 0 3.127-0.55 4.325-1.488-1.532-0.032-2.815-1.036-3.257-2.417 0.215 0.032 0.431 0.054 0.656 0.054 0.314 0 0.627-0.043 0.918-0.118-1.596-0.324-2.794-1.726-2.794-3.419 0-0.011 0-0.033 0-0.043 0.464 0.258 1.003 0.42 1.575 0.442-0.938-0.626-1.553-1.694-1.553-2.901 0-0.647 0.173-1.241 0.475-1.759 1.715 2.115 4.293 3.496 7.184 3.646-0.055-0.259-0.087-0.529-0.087-0.799 0-1.919 1.554-3.483 3.484-3.483 1.003 0 1.909 0.42 2.546 1.1 0.787-0.151 1.541-0.442 2.211-0.841-0.259 0.809-0.809 1.489-1.532 1.919 0.702-0.075 1.381-0.269 2.007-0.539-0.475 0.69-1.068 1.306-1.747 1.802z" fill="" />
                            </svg></a></li>
                                                            <li class="linkedin"><a  href="https://www.linkedin.com/company/adminuiux/"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="17" height="17" viewBox="0 0 17 17">
                                <path d="M0.698 5.823h3.438v10.323h-3.438v-10.323zM2.438 0.854c-1.167 0-1.938 0.771-1.938 1.782 0 0.989 0.74 1.781 1.896 1.781h0.021c1.198 0 1.948-0.792 1.938-1.781-0.011-1.011-0.74-1.782-1.917-1.782zM12.552 5.583c-1.829 0-2.643 1.002-3.094 1.709v-1.469h-3.427c0 0 0.042 0.969 0 10.323h3.427v-5.761c0-0.312 0.032-0.615 0.114-0.843 0.251-0.615 0.812-1.25 1.762-1.25 1.238 0 1.738 0.948 1.738 2.333v5.521h3.428v-5.917c0-3.167-1.688-4.646-3.948-4.646z" fill="" />
                            </svg></a></li>
                                                            <li class="instagram"><a  href="https://www.instagram.com/adminuiux"><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="17" height="17" viewBox="0 0 169.063 169.063" style="enable-background:new 0 0 169.063 169.063;" xml:space="preserve">
                                <g>
                                    <path d="M122.406,0H46.654C20.929,0,0,20.93,0,46.655v75.752c0,25.726,20.929,46.655,46.654,46.655h75.752c25.727,0,46.656-20.93,46.656-46.655V46.655C169.063,20.93,148.133,0,122.406,0z M154.063,122.407c0,17.455-14.201,31.655-31.656,31.655H46.654C29.2,154.063,15,139.862,15,122.407V46.655C15,29.201,29.2,15,46.654,15h75.752c17.455,0,31.656,14.201,31.656,31.655V122.407z" />
                                    <path d="M84.531,40.97c-24.021,0-43.563,19.542-43.563,43.563c0,24.02,19.542,43.561,43.563,43.561s43.563-19.541,43.563-43.561C128.094,60.512,108.552,40.97,84.531,40.97z M84.531,113.093c-15.749,0-28.563-12.812-28.563-28.561c0-15.75,12.813-28.563,28.563-28.563s28.563,12.813,28.563,28.563C113.094,100.281,100.28,113.093,84.531,113.093z" />
                                    <path d="M129.921,28.251c-2.89,0-5.729,1.17-7.77,3.22c-2.051,2.04-3.23,4.88-3.23,7.78c0,2.891,1.18,5.73,3.23,7.78c2.04,2.04,4.88,3.22,7.77,3.22c2.9,0,5.73-1.18,7.78-3.22c2.05-2.05,3.22-4.89,3.22-7.78c0-2.9-1.17-5.74-3.22-7.78C135.661,29.421,132.821,28.251,129.921,28.251z" />
                                </g>
                            </svg></a></li>
                                                        </ul>
            </div>
            </div>        </div>
    </div>
</nav>
				</div>
				</div>
					</div>
		</div>
					</div>
		</section>
					</div>
		</div>
					</div>
		</section>
				<section class="elementor-section elementor-top-section elementor-element elementor-element-fb29912 d-none elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="fb29912" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-1844bd5" data-id="1844bd5" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
						<div class="elementor-element elementor-element-6811356 elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-html" data-id="6811356" data-element_type="widget" data-settings="{&quot;_position&quot;:&quot;absolute&quot;}" data-widget_type="html.default">
					<script>
    jQuery('.rt-social-section .twitter a').attr('href', 'https://x.com/admiinuiux');
</script>				</div>
					</div>
		</div>
					</div>
		</section>
				</div>
		</div></header>        
                <!-- #page -->
        <div class="site">
            <!-- #content -->
            <div id="content" class="site-content">

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<!-- wraper_error_main -->
		<div class="wraper_error_main style-one">
			<!-- START OF 404 STYLE ONE CONTENT -->
			<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<!-- error_main -->
							<div class="error_main">
								<!-- apptek-content -->
																<h1><a href="https://www.adminuiux.com/wp-content/uploads/2022/10/error-404-image.svg"><img fetchpriority="high" class="alignnone size-full wp-image-42761" src="https://www.adminuiux.com/wp-content/uploads/2022/10/error-404-image.svg" alt="" width="632" height="247" /></a></h1>
<h2>OOPS! Nothing Was Found</h2>
<p>Oops! it could be you or us, there is no page here. It might have been moved or deleted.</p>																
								<!-- apptek-content -->

								<!-- apptek-button-link -->
																	<a class="btn" href="https://www.adminuiux.com"><span class="ti-arrow-left"></span> Back To Home</a>
																<!-- apptek-button-link -->
							</div>
							<!-- error_main -->
						</div>
					</div>
					<!-- row -->
				</div>
				<!-- END OF 404 STYLE ONE CONTENT -->
		</div>
		<!-- wraper_error_main -->
	</main><!-- #main -->
</div><!-- #primary -->

		</div>
		<!-- #content -->
	</div>
	<!-- #page -->
<!-- wraper_footer -->
<footer class="wraper_footer style-default">
	<!-- wraper_footer_copyright -->
	<div class="wraper_footer_copyright">
		<div class="container">
			<!-- footer_copyright -->
			<div class="row footer_copyright">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<!-- footer_copyright_item -->
					<div class="footer_copyright_item text-center">
						<p>Copyright © 2022 apptek. All Rights Reserved.</p>
					</div>
					<!-- footer_copyright_item -->
				</div>
			</div>
			<!-- footer_copyright -->
		</div>
	</div>
	<!-- wraper_footer_copyright -->
</footer>
<!-- wraper_footer -->
	</div>
<!-- apptek-website-layout -->
<script>
if (window.self != window.top) {
  // Example: Run some specific function
  function myPageSpecificFunction() {
    jQuery('#header').hide();
	jQuery('.wraper_footer').hide();
	  
	 if (document.referrer.includes('https://preview.themeforest.net')) {
      jQuery('body').addClass('yes-envato');
    }
  }
	

  myPageSpecificFunction();
}
</script>

<script type="speculationrules">
{"prefetch":[{"source":"document","where":{"and":[{"href_matches":"/*"},{"not":{"href_matches":["/wp-*.php","/wp-admin/*","/wp-content/uploads/*","/wp-content/*","/wp-content/plugins/*","/wp-content/themes/apptek/*","/*\\?(.+)"]}},{"not":{"selector_matches":"a[rel~=\"nofollow\"]"}},{"not":{"selector_matches":".no-prefetch, .no-prefetch a"}}]},"eagerness":"conservative"}]}
</script>
<div class="a2a_kit a2a_kit_size_32 a2a_floating_style a2a_vertical_style" data-a2a-scroll-show="0,100" style="left:0px;top:250px;background-color:transparent"><a class="a2a_button_twitter" href="https://www.addtoany.com/add_to/twitter?linkurl=https%3A%2F%2Fwww.adminuiux.com%2Fadminuiux%2Finvestment-uiux%2Fsrc%2Ficon.js&amp;linkname=Page%20Not%20Found" title="Twitter" rel="nofollow noopener" target="_blank"></a><a class="a2a_button_facebook" href="https://www.addtoany.com/add_to/facebook?linkurl=https%3A%2F%2Fwww.adminuiux.com%2Fadminuiux%2Finvestment-uiux%2Fsrc%2Ficon.js&amp;linkname=Page%20Not%20Found" title="Facebook" rel="nofollow noopener" target="_blank"></a><a class="a2a_button_linkedin" href="https://www.addtoany.com/add_to/linkedin?linkurl=https%3A%2F%2Fwww.adminuiux.com%2Fadminuiux%2Finvestment-uiux%2Fsrc%2Ficon.js&amp;linkname=Page%20Not%20Found" title="LinkedIn" rel="nofollow noopener" target="_blank"></a><a class="a2a_button_reddit" href="https://www.addtoany.com/add_to/reddit?linkurl=https%3A%2F%2Fwww.adminuiux.com%2Fadminuiux%2Finvestment-uiux%2Fsrc%2Ficon.js&amp;linkname=Page%20Not%20Found" title="Reddit" rel="nofollow noopener" target="_blank"></a><a class="a2a_dd a2a_counter addtoany_share_save addtoany_share" href="https://www.addtoany.com/share"></a></div>	<script>
jQuery(document).ready(function($){
$(document).on('click', '.plus', function(e) { // replace '.quantity' with document (without single quote)
	$input = $(this).prev('input.qty');
	var val = parseInt($input.val());
	var step = $input.attr('step');
	step = 'undefined' !== typeof(step) ? parseInt(step) : 1;
	$input.val( val + step ).change();
});
$(document).on('click', '.minus',  // replace '.quantity' with document (without single quote)
	function(e) {
	$input = $(this).next('input.qty');
	var val = parseInt($input.val());
	var step = $input.attr('step');
	step = 'undefined' !== typeof(step) ? parseInt(step) : 1;
	if (val > 0) {
		$input.val( val - step ).change();
	}
});
});
</script>
					<script>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
				<script>
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})();
	</script>
	<script id="wp-hooks-js" src="https://www.adminuiux.com/wp-includes/js/dist/hooks.min.js?ver=f0f188028580e8dc1255"></script>
<script id="wp-i18n-js" src="https://www.adminuiux.com/wp-includes/js/dist/i18n.min.js?ver=1dfe7db3940c23ea9216"></script>
<script id="wp-i18n-js-after">
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'ltr' ] } );
//# sourceURL=wp-i18n-js-after
</script>
<script id="swv-js" src="https://www.adminuiux.com/wp-content/plugins/contact-form-7/includes/swv/js/index.js?ver=6.1.4"></script>
<script id="contact-form-7-js-before">
var wpcf7 = {
    "api": {
        "root": "https:\/\/www.adminuiux.com\/wp-json\/",
        "namespace": "contact-form-7\/v1"
    }
};
//# sourceURL=contact-form-7-js-before
</script>
<script id="contact-form-7-js" src="https://www.adminuiux.com/wp-content/plugins/contact-form-7/includes/js/index.js?ver=6.1.4"></script>
<script id="underscore-js" src="https://www.adminuiux.com/wp-includes/js/underscore.min.js?ver=1.13.8"></script>
<script id="wp-util-js-extra">
var _wpUtilSettings = {"ajax":{"url":"/wp-admin/admin-ajax.php"}};
//# sourceURL=wp-util-js-extra
</script>
<script id="wp-util-js" src="https://www.adminuiux.com/wp-includes/js/wp-util.min.js?ver=7.1"></script>
<script id="wp-api-request-js-extra">
var wpApiSettings = {"root":"https://www.adminuiux.com/wp-json/","nonce":"2a12b2cfa5","versionString":"wp/v2/"};
//# sourceURL=wp-api-request-js-extra
</script>
<script id="wp-api-request-js" src="https://www.adminuiux.com/wp-includes/js/api-request.min.js?ver=7.1"></script>
<script id="wp-private-apis-js" src="https://www.adminuiux.com/wp-includes/js/dist/private-apis.min.js?ver=eb85f28c4c729bb4f002"></script>
<script id="wp-url-js" src="https://www.adminuiux.com/wp-includes/js/dist/url.min.js?ver=7b0de086d4ae11d55704"></script>
<script id="wp-api-fetch-js" src="https://www.adminuiux.com/wp-includes/js/dist/api-fetch.min.js?ver=6f2a4faeee3c722b1e57"></script>
<script id="wp-api-fetch-js-after">
wp.apiFetch.use( wp.apiFetch.createRootURLMiddleware( "https://www.adminuiux.com/wp-json/" ) );
wp.apiFetch.nonceMiddleware = wp.apiFetch.createNonceMiddleware( "2a12b2cfa5" );
wp.apiFetch.use( wp.apiFetch.nonceMiddleware );
wp.apiFetch.use( wp.apiFetch.mediaUploadMiddleware );
wp.apiFetch.nonceEndpoint = "https://www.adminuiux.com/wp-admin/admin-ajax.php?action=rest-nonce";
//# sourceURL=wp-api-fetch-js-after
</script>
<script id="wp-polyfill-js" src="https://www.adminuiux.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0"></script>
<script id="woo-variation-swatches-js-extra">
var woo_variation_swatches_options = {"show_variation_label":"1","clear_on_reselect":"","variation_label_separator":":","is_mobile":"","show_variation_stock":"","stock_label_threshold":"5","cart_redirect_after_add":"yes","enable_ajax_add_to_cart":"yes","cart_url":"https://www.adminuiux.com/?page_id=35477","is_cart":""};
//# sourceURL=woo-variation-swatches-js-extra
</script>
<script id="woo-variation-swatches-js" src="https://www.adminuiux.com/wp-content/plugins/woo-variation-swatches/assets/js/frontend.min.js?ver=1766032116"></script>
<script id="apptek-custom-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/apptek-custom.js?ver=1788624552"></script>
<script id="bootstrap-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/bootstrap.min.js?ver=1788624552"></script>
<script id="swiper-js" src="https://www.adminuiux.com/wp-content/plugins/elementor/assets/lib/swiper/v8/swiper.min.js?ver=8.4.5"></script>
<script id="menu-vendor-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/menu-vendor.js?ver=1788624552"></script>
<script id="apptek-new-left-menu-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/apptek-app.js?ver=1788624552"></script>
<script id="sidr-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/jquery.sidr.min.js?ver=1788624552"></script>
<script id="fancy-box-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/fancy-box.js?ver=1788624552"></script>
<script id="sweetalert-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/sweetalert.min.js?ver=1788624552"></script>
<script id="ajax_add_to_cart-js" src="https://www.adminuiux.com/wp-content/themes/apptek/assets/js/ajax_add_to_cart.js?ver=1788624552"></script>
<script id="sourcebuster-js-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/sourcebuster/sourcebuster.min.js?ver=9.8.7"></script>
<script id="wc-order-attribution-js-extra">
var wc_order_attribution = {"params":{"lifetime":1.0e-5,"session":30,"base64":false,"ajaxurl":"https://www.adminuiux.com/wp-admin/admin-ajax.php","prefix":"wc_order_attribution_","allowTracking":true},"fields":{"source_type":"current.typ","referrer":"current_add.rf","utm_campaign":"current.cmp","utm_source":"current.src","utm_medium":"current.mdm","utm_content":"current.cnt","utm_id":"current.id","utm_term":"current.trm","utm_source_platform":"current.plt","utm_creative_format":"current.fmt","utm_marketing_tactic":"current.tct","session_entry":"current_add.ep","session_start_time":"current_add.fd","session_pages":"session.pgs","session_count":"udata.vst","user_agent":"udata.uag"}};
//# sourceURL=wc-order-attribution-js-extra
</script>
<script id="wc-order-attribution-js" src="https://www.adminuiux.com/wp-content/plugins/woocommerce/assets/js/frontend/order-attribution.min.js?ver=9.8.7"></script>
<script id="font-awesome-4-shim-js" src="https://www.adminuiux.com/wp-content/plugins/elementor/assets/lib/font-awesome/js/v4-shims.min.js?ver=3.27.7"></script>
<script id="elementor-webpack-runtime-js" src="https://www.adminuiux.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.27.7"></script>
<script id="elementor-frontend-modules-js" src="https://www.adminuiux.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.27.7"></script>
<script id="jquery-ui-core-js-before">
jQuery.uiBackCompat = true;
//# sourceURL=jquery-ui-core-js-before
</script>
<script id="jquery-ui-core-js" src="https://www.adminuiux.com/wp-includes/js/jquery/ui/core.min.js?ver=1.14.2"></script>
<script id="elementor-frontend-js-before">
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"Share on Facebook","shareOnTwitter":"Share on Twitter","pinIt":"Pin it","download":"Download","downloadImage":"Download image","fullscreen":"Fullscreen","zoom":"Zoom","share":"Share","playVideo":"Play Video","previous":"Previous","next":"Next","close":"Close","a11yCarouselPrevSlideMessage":"Previous slide","a11yCarouselNextSlideMessage":"Next slide","a11yCarouselFirstSlideMessage":"This is the first slide","a11yCarouselLastSlideMessage":"This is the last slide","a11yCarouselPaginationBulletMessage":"Go to slide"},"is_rtl":false,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":true},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":true},"laptop":{"label":"Laptop","value":1900,"default_value":1366,"direction":"max","is_enabled":true},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":true}},"hasCustomBreakpoints":true},"version":"3.27.7","is_static":false,"experimentalFeatures":{"additional_custom_breakpoints":true,"e_swiper_latest":true,"e_optimized_markup":true,"e_onboarding":true,"home_screen":true,"landing-pages":true,"editor_v2":true,"link-in-bio":true,"floating-buttons":true},"urls":{"assets":"https:\/\/www.adminuiux.com\/wp-content\/plugins\/elementor\/assets\/","ajaxurl":"https:\/\/www.adminuiux.com\/wp-admin\/admin-ajax.php","uploadUrl":"https:\/\/www.adminuiux.com\/wp-content\/uploads"},"nonces":{"floatingButtonsClickTracking":"b78a3d5568"},"swiperClass":"swiper","settings":{"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_mobile_extra","viewport_tablet","viewport_tablet_extra","viewport_laptop","viewport_widescreen"],"viewport_laptop":1900,"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":0,"title":"Page Not Found","excerpt":""}};
//# sourceURL=elementor-frontend-js-before
</script>
<script id="elementor-frontend-js" src="https://www.adminuiux.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.27.7"></script>
<script id="wp-emoji-settings" type="application/json">
{"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://www.adminuiux.com/wp-includes/js/wp-emoji-release.min.js?ver=7.1"}}
</script>
<script type="module">
/*! This file is auto-generated */
var e="script#wp-emoji-settings",t=document.querySelector(e);if(!(t instanceof HTMLScriptElement))throw new Error("Element missing: "+e);const r=JSON.parse(t.text),s=(window._wpemojiSettings=r,"wpEmojiSettingsSupports"),o=["flag","emoji"];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(s,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const r=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===r[t])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data[e])return!1;return!0}function u(e,t,n,r){switch(t){case"flag":return n(e,"\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f","\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f")?!1:!n(e,"\ud83c\udde8\ud83c\uddf6","\ud83c\udde8\u200b\ud83c\uddf6")&&!n(e,"\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f","\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");case"emoji":return!r(e,"\ud83e\u1fac8")}return!1}function f(e,t,n,r){let a;const s=(a="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),o=(s.textBaseline="top",s.font="600 32px Arial",{});return e.forEach(e=>{o[e]=t(s,e,n,r)}),o}function a(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}r.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(s));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+[JSON.stringify(o),u.toString(),c.toString(),p.toString()].join(",")+"));",r=new Blob([e],{type:"text/javascript"});const a=new Worker(URL.createObjectURL(r),{name:"wpTestEmojiSupports"});return void(a.onmessage=e=>{i(n=e.data),a.terminate(),t(n)})}catch(e){}i(n=f(o,u,c,p))}t(n)}).then(e=>{for(const n in e)r.supports[n]=e[n],r.supports.everything=r.supports.everything&&r.supports[n],"flag"!==n&&(r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&r.supports[n]);var t;r.supports.everythingExceptFlag=r.supports.everythingExceptFlag&&!r.supports.flag,r.supports.everything||((t=r.source||{}).concatemoji?a(t.concatemoji):t.wpemoji&&t.twemoji&&(a(t.twemoji),a(t.wpemoji)))});
//# sourceURL=https://www.adminuiux.com/wp-includes/js/wp-emoji-loader.min.js
</script>
	</body>
</html>
